// background.js — MV3 service worker

let popupPort = null;

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'popup') {
    popupPort = port;
    port.onDisconnect.addListener(() => {
      popupPort = null;
    });
  }
});

function forwardLog(message) {
  if (popupPort) {
    try {
      popupPort.postMessage(message);
      return;
    } catch (_) {}
  }
  // Fallback: nếu popup chưa mở, gửi broadcast — popup.js cũng lắng nghe để ghi log
  try {
    chrome.runtime.sendMessage(message);
  } catch (_) {}
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'log') {
    forwardLog({ type: 'log', level: msg.level || 'info', text: msg.text || '' });
    sendResponse && sendResponse({ ok: true });
    return; // sync
  }
});
