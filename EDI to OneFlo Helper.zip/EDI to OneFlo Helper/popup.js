// Send log to popup display
function sendLog(level, text) {
  const logContainer = document.getElementById('log');
  if (!logContainer) {
    console.error('Log container not found!');
    return;
  }
  const logEntry = document.createElement('div');
  logEntry.className = `log-entry ${level}`;
  logEntry.textContent = text;
  logContainer.appendChild(logEntry);
  logContainer.scrollTop = logContainer.scrollHeight;
}

// Detect EDI page type
async function detectEDIPageType(tabId) {
  try {
    const result = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        if (document.getElementById('lookup_button')) {
          return 'web2';
        }
        if (document.querySelector('form[name="tracking"]') || 
            document.getElementById('consignmentdetails') ||
            document.getElementById('key')) {
          return 'web3';
        }
        return 'unknown';
      }
    });
    return result[0]?.result;
  } catch (error) {
    console.error('Error detecting page type:', error);
    return 'unknown';
  }
}

// Process Web 2 (AP Entry)
async function processWeb2(tabId, barcode) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, { action: 'processBarcode', barcode }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error('AP Entry error: ' + chrome.runtime.lastError.message));
      } else if (!response) {
        reject(new Error('No response from AP Entry'));
      } else {
        resolve(response);
      }
    });
  });
}

// Process Web 3 (Tracking) with polling after redirect
async function processWeb3(tabId, barcode) {
  return new Promise(async (resolve) => {
    try {
      // Check if we need to click main menu first
      const needsReset = await chrome.tabs.sendMessage(tabId, { 
        action: 'checkNeedsReset' 
      });
      
      if (needsReset) {
       
        
        // Click main menu
        await chrome.tabs.sendMessage(tabId, { action: 'clickMainMenu' });
        
        // Wait for page reload after clicking main menu
        await new Promise(r => setTimeout(r, 2000));
        
        // Poll until #key input is available
        const maxResetAttempts = 3;
        let resetAttempts = 0;
        let keyInputReady = false;
        
        while (resetAttempts < maxResetAttempts && !keyInputReady) {
          resetAttempts++;
          
          try {
            const checkResult = await chrome.tabs.sendMessage(tabId, { 
              action: 'checkKeyInput' 
            });
            
            if (checkResult && checkResult.ready) {
              keyInputReady = true;
              break;
            }
          } catch (error) {
            // Continue polling
          }
          
          await new Promise(r => setTimeout(r, 500));
        }
        
        if (!keyInputReady) {
          sendLog('error', '❌ Cannot access Tracking form after reset');
          resolve(null);
          return;
        }
        
        
      }
      
      // Submit form
      const submitResult = await chrome.tabs.sendMessage(tabId, { 
        action: 'processWeb3', 
        barcode 
      });
      
      if (!submitResult || submitResult.status === 'error') {
        resolve(null);
        return;
      }
      
      // Wait for page reload
      await new Promise(r => setTimeout(r, 2000));
      
      // Polling
      const maxAttempts = 2;
      let attempts = 0;
      
      const pollInterval = setInterval(async () => {
        attempts++;
        
        try {
          const result = await chrome.tabs.sendMessage(tabId, { 
            action: 'extractPhone' 
          });
          
          if (result.status === 'success') {
            clearInterval(pollInterval);
            resolve({ phoneNumber: result.phoneNumber });
          } else if (result.status === 'no_phone') {
            clearInterval(pollInterval);
            resolve(null);
          } else if (result.status === 'not_ready') {
            if (attempts >= maxAttempts) {
              clearInterval(pollInterval);
              resolve(null);
            }
          }
        } catch (error) {
          if (attempts >= maxAttempts) {
            clearInterval(pollInterval);
            resolve(null);
          }
        }
      }, 500);
      
    } catch (error) {
      resolve(null);
    }
  });
}

// Main action
async function mainAction() {
  try {
    sendLog('info', '⏳ Processing...');

    // Query all tabs
    const tabs = await chrome.tabs.query({});

    // STEP 1: Find OneFlo tab
    const web1Tab = tabs.find(tab => tab.url && tab.url.includes('https://portal.oneflo.com.au/CreateConsignment'));
    if (!web1Tab) {
      sendLog('error', '❌ Please reload OneFlo');
      return;
    }
    sendLog('success', '✓ OneFlo tab found');

    // STEP 2: Find EDI tabs
    const ediTabs = tabs.filter(tab => 
      tab.url && (
        tab.url.startsWith('https://edi.couriersplease.com.au/index.php') ||
        tab.url.startsWith('https://edi.couriersplease.com.au/')
      )
    );
    
    if (ediTabs.length === 0) {
      sendLog('error', '❌ Please reload at least 1 EDI tab (AP Entry is required)');
      return;
    }

    // Detect Web 2 and Web 3
    let web2Tab = null;
    let web3Tab = null;

    for (const tab of ediTabs) {
      const pageType = await detectEDIPageType(tab.id);
      if (pageType === 'web2') {
        web2Tab = tab;
      } else if (pageType === 'web3') {
        web3Tab = tab;
      }
    }

    // Web 2 is REQUIRED
    if (!web2Tab) {
      sendLog('error', '❌ EDI AP Entry tab not found (required)');
      return;
    }

    sendLog('success', '✓ EDI AP Entry tab found');
    
    // Web 3 is OPTIONAL
    if (web3Tab) {
      sendLog('success', '✓ EDI Tracking tab found');
    } else {
      sendLog('error', '⚠  EDI Tracking tab not found (will skip phone number)');
    }

    // STEP 3: Get barcode from OneFlo
    const barcodeResult = await chrome.scripting.executeScript({
      target: { tabId: web1Tab.id },
      func: () => {
        const element = document.querySelector('#dispatchDetailsInput > div:nth-child(1) > div.row.form-group > div > span > span.selection > span > ul > li.select2-selection__choice');
        return element ? element.getAttribute('title') : null;
      },
    });

    const barcode = barcodeResult[0]?.result;
    if (!barcode) {
      sendLog('error', '❌ Please enter Barcode in Reference');
      return;
    }
    sendLog('success', `✓ Barcode found: ${barcode}`);

    // STEP 4: Process Web 2 (AP Entry) - REQUIRED
    const web2Response = await processWeb2(web2Tab.id, barcode);

    if (!web2Response || !web2Response.suburb) {
      sendLog('error', '❌ No data from AP Entry');
      return;
    }
    sendLog('success', '✓ Data received from AP Entry');
    sendLog('info', `* Receiver Name: ${web2Response.addr1 || ''}`);
    sendLog('info', `* Address line 1: ${web2Response.addr2 || ''}`);
    sendLog('info', `* Address line 2: ${web2Response.addr3 || ''}`);
    sendLog('info', `* Suburb: ${web2Response.suburb || ''}`);

    // STEP 5: Process Web 3 (Tracking) - OPTIONAL
    let phoneNumber = null;
    
    if (web3Tab) {
      const web3Response = await processWeb3(web3Tab.id, barcode);

      if (web3Response && web3Response.phoneNumber) {
        phoneNumber = web3Response.phoneNumber;
        sendLog('success', `✓ Phone number received from Tracking: ${phoneNumber}`);
      } else {
        sendLog('info', '⚠ No phone number from Tracking');
      }
    }

    // STEP 6: Fill data into OneFlo
    const result = await chrome.tabs.sendMessage(web1Tab.id, {
      action: 'setReceiverLocation',
      location: web2Response.suburb,
      receiverName: web2Response.addr1,
      receiverAddressLine1: web2Response.addr2,
      receiverAddressLine2: web2Response.addr3,
      receiverPhone: phoneNumber,
      barcode,
    });

    if (result) {
      sendLog('success', '✓ All details filled into OneFlo');
      
      // STEP 7: Reset Web 3 (if exists)
      if (web3Tab) {
        await chrome.tabs.sendMessage(web3Tab.id, { action: 'clickMainMenu' });
       
      }
      
      sendLog('success', '✅ Done!');
    } else {
      sendLog('error', '❌ Cannot fill data into OneFlo');
    }
  } catch (error) {
    sendLog('error', `❌ Error: ${error.message || error}`);
    console.error('Main action error:', error);
  }
}

// Initialize when popup opens
document.addEventListener('DOMContentLoaded', () => {
  console.log('Popup loaded');
  
  const logContainer = document.getElementById('log');
  if (!logContainer) {
    console.error('Log container not found in DOM!');
    return;
  }

  // Listen for logs from background or content scripts
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'log') {
      const logEntry = document.createElement('div');
      logEntry.className = `log-entry ${message.level}`;
      logEntry.textContent = message.text;
      logContainer.appendChild(logEntry);
      logContainer.scrollTop = logContainer.scrollHeight;
    }
  });

  // Execute main action
  mainAction();
});