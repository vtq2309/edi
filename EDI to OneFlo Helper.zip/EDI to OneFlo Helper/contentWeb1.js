// Hàm gửi log đến background script
function sendLogToBackground(level, text) {
  chrome.runtime.sendMessage({ type: 'log', level, text }, (response) => {
    if (chrome.runtime.lastError) {
      console.warn('Error sending log to background:', chrome.runtime.lastError.message);
    }
  });
}

// Hàm tạo độ trễ (delay) cho các thao tác bất đồng bộ
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Log để kiểm tra script đã được tải
console.log('ContentWeb1 script loaded.');

// Thêm hiệu ứng nổi bật cho phần tử đang được thao tác
function highlightElement(element) {
  if (!element) return;
  element.style.transition = 'box-shadow 0.3s ease';
  element.style.boxShadow = '0 0 10px 2px #3498db';
  setTimeout(() => {
    element.style.boxShadow = '';
  }, 2000);
}

// Lắng nghe các message được gửi từ popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'setReceiverLocation') {
    handleSetReceiverLocation(request)
      .then(() => {
        console.log('Completed setReceiverLocation!');
        sendResponse(true);
      })
      .catch((error) => {
        console.error('Error in setReceiverLocation:', error);
        sendResponse(false);
      });
    return true;
  }
});

// Hàm async để xử lý việc điền thông tin vào các trường của form
async function handleSetReceiverLocation(request) {
  console.log('Processing setReceiverLocation with data:', request);

  // Lấy các input field bằng ID
  const receiverLocationInput = document.getElementById('receiverLocation');
  const receiverNameInput = document.getElementById('receiverName');
  const receiverAddressLine1Input = document.getElementById('receiverAddressLine1');
  const receiverAddressLine2Input = document.getElementById('receiverAddressLine2');
  const receiverPhoneInput = document.getElementById('receiverPhone');

  // Kiểm tra các input field
  if (!receiverLocationInput || !receiverNameInput || !receiverAddressLine1Input || !receiverAddressLine2Input) {
    console.error('Required fields not found!');
    throw new Error('Required fields not found on OneFlo.');
  }

  // Điền thông tin từ Web 2
  highlightElement(receiverLocationInput);
  receiverLocationInput.value = request.location;
  receiverLocationInput.dispatchEvent(new Event('input', { bubbles: true }));
  receiverLocationInput.dispatchEvent(new Event('change', { bubbles: true }));

  highlightElement(receiverNameInput);
  receiverNameInput.value = request.receiverName;
  receiverNameInput.dispatchEvent(new Event('input', { bubbles: true }));
  receiverNameInput.dispatchEvent(new Event('change', { bubbles: true }));

  highlightElement(receiverAddressLine1Input);
  receiverAddressLine1Input.value = request.receiverAddressLine1;
  receiverAddressLine1Input.dispatchEvent(new Event('input', { bubbles: true }));
  receiverAddressLine1Input.dispatchEvent(new Event('change', { bubbles: true }));

  highlightElement(receiverAddressLine2Input);
  receiverAddressLine2Input.value = request.receiverAddressLine2;
  receiverAddressLine2Input.dispatchEvent(new Event('input', { bubbles: true }));
  receiverAddressLine2Input.dispatchEvent(new Event('change', { bubbles: true }));

  // Điền phone number từ Web 3 (nếu có)
  if (request.receiverPhone && receiverPhoneInput) {
    highlightElement(receiverPhoneInput);
    receiverPhoneInput.value = request.receiverPhone;
    receiverPhoneInput.dispatchEvent(new Event('input', { bubbles: true }));
    receiverPhoneInput.dispatchEvent(new Event('change', { bubbles: true }));
  }

  // Chỉ check checkbox #authorityToLeave
  await delay(100);
  
  const authorityToLeave = document.querySelector("#authorityToLeave");
  if (authorityToLeave && !authorityToLeave.checked) {
    highlightElement(authorityToLeave);
    authorityToLeave.click();
    console.log("Checked #authorityToLeave checkbox");
  }
}