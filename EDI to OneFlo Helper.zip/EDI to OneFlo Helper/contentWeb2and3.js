// contentWeb2and3.js - Handles both Web 2 (AP Entry) and Web 3 (Tracking)

function sendLogToBackground(level, text) {
  chrome.runtime.sendMessage({ type: 'log', level, text }, (response) => {
    if (chrome.runtime.lastError) {
      console.warn('Error sending log to background:', chrome.runtime.lastError.message);
    } else {
      console.log('Log sent to background:', response);
    }
  });
}

// Function to detect current page type
function detectCurrentPage() {
  // Check Web 2 (AP Entry) - has lookup_button
  if (document.getElementById('lookup_button')) {
    return 'web2';
  }
  
  // Check Web 3 (Tracking) - is EDI tab but does NOT have lookup_button
  // Or has tracking form, or has consignmentdetails, or has input#key
  if (document.querySelector('form[name="tracking"]') || 
      document.getElementById('consignmentdetails') ||
      document.getElementById('key')) {
    return 'web3';
  }
  
  return 'unknown';
}

console.log('ContentWeb2and3 script loaded. Page type:', detectCurrentPage());

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const pageType = detectCurrentPage();
  
  // Handle Web 2 (AP Entry)
  if (request.action === 'processBarcode' && pageType === 'web2') {
    handleWeb2ProcessBarcode(request, sendResponse);
    return true;
  }
  
  // Handle Web 3 (Tracking) - Check if needs reset
  if (request.action === 'checkNeedsReset' && pageType === 'web3') {
    const needsReset = checkIfNeedsReset();
    sendResponse(needsReset);
    return true;
  }
  
  // Handle Web 3 (Tracking) - Check if key input is ready
  if (request.action === 'checkKeyInput' && pageType === 'web3') {
    const keyInput = document.getElementById('key');
    sendResponse({ ready: !!keyInput });
    return true;
  }
  
  // Handle Web 3 (Tracking) - Submit form
  if (request.action === 'processWeb3' && pageType === 'web3') {
    handleWeb3Process(request, sendResponse);
    return true;
  }
  
  // Handle Web 3 (Tracking) - Extract phone after redirect
  if (request.action === 'extractPhone' && pageType === 'web3') {
    const result = extractPhoneFromConsignment();
    sendResponse(result);
    return true;
  }
  
  // Click main menu on Web 3
  if (request.action === 'clickMainMenu' && pageType === 'web3') {
    clickMainMenu();
    sendResponse(true);
    return true;
  }
  
  // If action doesn't match page type
  if (request.action === 'processBarcode' || request.action === 'processWeb3') {
    const expectedPage = request.action === 'processBarcode' ? 'AP Entry (Web 2)' : 'Tracking (Web 3)';
    sendLogToBackground('error', `Wrong page! Expected ${expectedPage} but found ${pageType}`);
    sendResponse(null);
  }
});

// ==================== WEB 2 HANDLER (AP Entry) ====================
function handleWeb2ProcessBarcode(request, sendResponse) {
  const barcode = request.barcode;

  const scanBarcodeInput = document.getElementById('scanbarcode');
  if (!scanBarcodeInput) {
    sendResponse(null);
    return;
  }

  scanBarcodeInput.value = barcode;

  const suburbElement = document.getElementById('consignment_s_suburb');
  const addr1Element = document.getElementById('addr1');
  const addr2Element = document.getElementById('addr2');
  const addr3Element = document.getElementById('addr3');

  if (suburbElement) {
    suburbElement.value = '';
  } else {
    sendResponse(null);
    return;
  }

  scanBarcodeInput.dispatchEvent(new Event('input', { bubbles: true }));
  scanBarcodeInput.dispatchEvent(new Event('change', { bubbles: true }));

  // Click lookup button
  const clickLookupButton = () => {
    const lookupButton = document.getElementById('lookup_button');
    if (lookupButton) {
      lookupButton.scrollIntoView();
      setTimeout(() => {
        const clickEvent = new MouseEvent('click', {
          view: window,
          bubbles: true,
          cancelable: true
        });
        lookupButton.dispatchEvent(clickEvent);
      }, 200);
      return true;
    }
    return false;
  };

  if (!clickLookupButton()) {
    const buttonObserver = new MutationObserver((mutations, obs) => {
      if (clickLookupButton()) {
        obs.disconnect();
      }
    });
    buttonObserver.observe(document.body, { childList: true, subtree: true });
  }

  // Polling
  const pollInterval = 100;
  let pollTimer = null;

  const checkSuburb = () => {
    const suburb = suburbElement.value || suburbElement.textContent;
    const addr1 = addr1Element ? (addr1Element.value || addr1Element.textContent) : '';
    const addr2 = addr2Element ? (addr2Element.value || addr2Element.textContent) : '';
    const addr3 = addr3Element ? (addr3Element.value || addr3Element.textContent) : '';

    if (suburb) {
      sendResponse({ suburb, addr1, addr2, addr3 });
      clearInterval(pollTimer);
      clearTimeout(timeoutId);
    }
  };

  pollTimer = setInterval(checkSuburb, pollInterval);

  const timeoutId = setTimeout(() => {
    const suburb = suburbElement.value || suburbElement.textContent || null;
    const addr1 = addr1Element ? (addr1Element.value || addr1Element.textContent) : '';
    const addr2 = addr2Element ? (addr2Element.value || addr2Element.textContent) : '';
    const addr3 = addr3Element ? (addr3Element.value || addr3Element.textContent) : '';
    sendResponse({ suburb, addr1, addr2, addr3 });
    clearInterval(pollTimer);
  }, 2000);
}

// ==================== WEB 3 HANDLER (Tracking) ====================

// Check if Web 3 is on consignment details page (needs reset)
function checkIfNeedsReset() {
  const consignmentDiv = document.getElementById('consignmentdetails');
  const keyInput = document.getElementById('key');
  
  // If has consignmentdetails BUT no input#key => needs reset
  if (consignmentDiv && !keyInput) {
    return true;
  }
  
  return false;
}

function handleWeb3Process(request, sendResponse) {
  const barcode = request.barcode;
  
  // STEP 1: Get key input
  const keyInput = document.getElementById('key');
  if (!keyInput) {
    sendLogToBackground('error', 'Input Barcode not found on Tracking');
    sendResponse({ status: 'error', message: 'key input not found' });
    return;
  }
  
  // STEP 2: Fill barcode into key input
  keyInput.value = barcode;
  keyInput.dispatchEvent(new Event('input', { bubbles: true }));
  keyInput.dispatchEvent(new Event('change', { bubbles: true }));
  
  // STEP 3: Click submit button
  const submitButton = document.querySelector('#content > form > input[type=submit]:nth-child(3)');
  if (!submitButton) {
    sendLogToBackground('error', 'Submit button not found on Web 3');
    sendResponse({ status: 'error', message: 'submit button not found' });
    return;
  }
  
  // Click submit button - page will redirect
  submitButton.click();
  
  // Response immediately because page will reload
  sendResponse({ status: 'submitted' });
}

// Function to extract phone number from consignment details (called from popup after page reload)
function extractPhoneFromConsignment() {
  const consignmentDiv = document.getElementById('consignmentdetails');
  
  if (!consignmentDiv) {
    return { status: 'not_ready' };
  }
  
  console.log('Consignment HTML preview:', consignmentDiv.innerHTML.substring(0, 500));
  
  // Find row with th containing "Contact Details"
  const rows = consignmentDiv.querySelectorAll('table > tbody > tr');
  
  console.log('Total rows found:', rows.length);
  
  for (let i = 0; i < rows.length; i++) {
    const th = rows[i].querySelector('th');
    const thText = th ? th.textContent.trim() : '';
    
    if (th && thText === 'Contact Details') {
      const td = rows[i].querySelector('td');
      if (td) {
        const tdHTML = td.innerHTML;
        const tdText = td.textContent || td.innerText;
        
        console.log('Contact Details td HTML:', tdHTML);
        console.log('Contact Details td Text:', tdText);
        
        // Define phone number patterns in priority order
        // Match exact lengths, some patterns allow digits after to handle cases like email addresses
        const phonePatterns = [
          // Prioritize 04xxxxxxxx before 4xxxxxxxx (10 digits total with various spacing)
          /(?<!\d)04\d{8}/,                                    // 0409220239 (10 digits, no space)
          /(?<!\d)04\d{2}\s\d{3}\s\d{3}/,                      // 0429 809 363 (with spaces)
          /(?<!\d)04\s\d{2}\s\d{3}\s\d{3}/,                    // 04 29 809 363
          /(?<!\d)04\s?\d{4}\s?\d{4}/,                         // 04 9220 2239 or 0499202239
          // International formats with + (should be +61 followed by 0X XXXXXXXX = total 12 digits)
          /\+61\s?0?4\d{8}/,                                   // +610439451057 or +61439451057 or +61 04 39451057
          /\+61\s?0?4\d{2}\s\d{3}\s\d{3}/,                     // +61 04 29 809 363
          /\+61\s?0?2\d{8}/,                                   // +610269718200 or +61269718200
          /\+61\s?0?2\d{4}\s\d{4}/,                            // +61 02 6971 8200
          // International without + (61 followed by mobile/landline)
          /(?<!\d)61\s?0?4\d{8}/,                              // 610439451057 or 61439451057
          /(?<!\d)61\s?0?2\d{8}/,                              // 610269718200 or 61269718200
          // Prioritize 02xxxxxxxx before 2xxxxxxxx (10 digits total)
          /\(02\)\s?\d{4}\s?\d{4}/,                            // (02) xxxx xxxx
          /(?<!\d)02\s?\d{4}\s?\d{4}/,                         // 02 xxxx xxxx or 02xxxxxxxx
          /(?<!\d)02\d{8}/,                                    // 02xxxxxxxx (10 digits, no space)
          /(?<!\d)02\d{4}\s\d{4}/,                             // 026971 8200 (with space)
          // 9 digits (4xxxxxxxx or 2xxxxxxxx) - only if no 0 before
          /(?<!\d)4\d{8}(?!\d)/,                               // 4xxxxxxxx
          /(?<!\d)2\d{8}(?!\d)/                                // 2xxxxxxxx
        ];
        
        // Try each pattern in priority order
        for (const pattern of phonePatterns) {
          const match = tdText.match(pattern);
          if (match) {
            // Remove only spaces and parentheses, keep the + sign if present
            const phoneNumber = match[0].replace(/[\s()]/g, '');
            console.log('Found phone number:', phoneNumber, 'with pattern:', pattern);
            return { status: 'success', phoneNumber };
          }
        }
        
        console.log('No matching phone pattern found');
      }
    }
  }
  
  return { status: 'no_phone' };
}

// Function to click main menu
function clickMainMenu() {
  const mainMenuLink = document.querySelector('a.mainmenulink[href="index.php"]');
  if (mainMenuLink) {
    mainMenuLink.click();
    return true;
  } else {
    sendLogToBackground('error', 'Main menu link not found on Web 3');
    return false;
  }
}

// ==================== UTILITY FUNCTIONS ====================

// Function to wait for element to appear in DOM with timeout
function waitForElement(selector, timeout = 2000) {
  return new Promise((resolve, reject) => {
    const element = document.querySelector(selector);
    if (element) {
      resolve(element);
      return;
    }
    
    const observer = new MutationObserver(() => {
      const element = document.querySelector(selector);
      if (element) {
        observer.disconnect();
        clearTimeout(timeoutId);
        resolve(element);
      }
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
    
    const timeoutId = setTimeout(() => {
      observer.disconnect();
      reject('Element not found within timeout');
    }, timeout);
  });
}